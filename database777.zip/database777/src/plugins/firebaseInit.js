// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyC4gQQqRhAU1O_vD2pf4gXafeZieKs_2vg",
  authDomain: "database-3c020.firebaseapp.com",
  projectId: "database-3c020",
  storageBucket: "database-3c020.appspot.com",
  messagingSenderId: "822985873526",
  appId: "1:822985873526:web:f912ae9378d9f8c8d42757",
  measurementId: "G-B403Z29N17",
});

const db = getFirestore(firebaseApp);
export default db;
